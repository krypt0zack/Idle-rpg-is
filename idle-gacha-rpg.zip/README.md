
# idle-gacha-rpg

Petit idle game inspiré des jeux mobiles de type RPG / Gacha.

Créé par **Krypt0QcZack** ✨

## Fonctionnalités

- Combat automatique
- Système de prestige
- Système de gacha (équipement aléatoire)
- Navigation par onglets
- Sauvegarde auto (localStorage)
