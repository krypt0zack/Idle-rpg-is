
let hero = {
  name: "Champi",
  lvl: 1,
  xp: 0,
  xpMax: 10,
  atk: 1,
  gold: 0,
  equipment: {},
  prestiges: 0
};
let enemy = { name: "Slime", hp: 5, maxHp: 5, atk: 1 };

function initGame() {
  setInterval(gameLoop, 1000);
  updateUI();
}

function gameLoop() {
  enemy.hp -= hero.atk;
  if (enemy.hp <= 0) {
    hero.gold += 5;
    hero.xp += 1;
    if (hero.xp >= hero.xpMax) {
      hero.lvl++;
      hero.xp = 0;
      hero.xpMax += 5;
      hero.atk += 1;
    }
    enemy.hp = enemy.maxHp;
  }
  updateUI();
}

function updateUI() {
  document.getElementById("heroGold").innerText = hero.gold;
  document.getElementById("heroAtk").innerText = hero.atk;
  document.getElementById("heroXp").innerText = hero.xp;
  document.getElementById("heroXpMax").innerText = hero.xpMax;
  document.getElementById("heroLvl").innerText = hero.lvl;
  document.getElementById("enemyHp").innerText = enemy.hp;
  document.getElementById("enemyName").innerText = enemy.name;
  document.getElementById("prestiges").innerText = hero.prestiges;
}

function showTab(name) {
  document.querySelectorAll('.tab').forEach(tab => tab.style.display = 'none');
  document.getElementById(name).style.display = 'block';
}

function changeZone(name, hp, atk) {
  enemy.name = name;
  enemy.maxHp = hp;
  enemy.hp = hp;
  enemy.atk = atk;
}

function prestige() {
  if (hero.lvl >= 5) {
    hero = { ...hero, lvl: 1, xp: 0, xpMax: 10, atk: 1, gold: 0, equipment: {}, prestiges: hero.prestiges + 1 };
    enemy = { name: "Slime", hp: 5, maxHp: 5, atk: 1 };
  }
}

function pullGacha() {
  if (hero.gold < 20) {
    document.getElementById("gachaResult").innerText = "💸 Pas assez d’or !";
    return;
  }
  hero.gold -= 20;
  const rand = Math.random();
  let rarity = "commun";
  if (rand < 0.1) rarity = "épique";
  else if (rand < 0.4) rarity = "rare";

  const gachaItems = {
    "commun": [{ slot: "weapon", name: "Bâton cassé", bonus: 2 }],
    "rare": [{ slot: "weapon", name: "Épée argentée", bonus: 4 }],
    "épique": [{ slot: "weapon", name: "Lame du chaos", bonus: 8 }]
  };

  const items = gachaItems[rarity];
  const item = items[Math.floor(Math.random() * items.length)];
  if (hero.equipment[item.slot]) hero.atk -= hero.equipment[item.slot].bonus;
  hero.equipment[item.slot] = item;
  hero.atk += item.bonus;
  document.getElementById("gachaResult").innerHTML =
    `✨ <b>${item.name}</b> obtenu !<br>` +
    `🎖 Rareté : <span style="color:${rarityColor(rarity)}">${rarity}</span><br>` +
    `+${item.bonus} atk<br>Équipé automatiquement.`;
}

function rarityColor(rarity) {
  switch(rarity) {
    case "commun": return "#aaa";
    case "rare": return "#4ab1f5";
    case "épique": return "#a84cf4";
  }
}
